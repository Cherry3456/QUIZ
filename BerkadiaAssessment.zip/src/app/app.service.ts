import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class AppService {
  res: any;
  constructor(private http:HttpClient) {

   }
  getJson(i:string) {
    const url = 'http://localhost/bkd/data.php?single='+i;
    this.res = this.http.get(url);
    return this.res;
  }
  getTotal() {
    const url1 = 'http://localhost/bkd/data.php?total=27';
    this.res = this.http.get(url1);
    return this.res;
  }

  getall() {
    const url1 = 'http://localhost/bkd/data.php?alldata=27';
    this.res = this.http.get(url1);
    return this.res;
  }
}
