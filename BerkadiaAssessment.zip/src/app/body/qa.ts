export class Qa{
    ans: string;
    id: string;
    constructor(id:string,ans:string)
    {
   this.id = id;
   this.ans = ans;
    }
}
