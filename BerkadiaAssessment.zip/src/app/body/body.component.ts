import { Component, OnInit } from '@angular/core';
import { AppService } from '../app.service';
import { Qa } from './qa';

@Component({
  selector: 'app-body',
  templateUrl: './body.component.html',
  styleUrls: ['./body.component.css']
})
export class BodyComponent implements OnInit {
  finalclick=false;
  finalcorrect=0;
  finalwrong=0;
  question:any[];
  answers: Qa[]=[];
  checkflag=false;
  previous=-1;
  next=1;
  total=0;
  nextflag=false;
  finalbtnflag=false;

  constructor(private service:AppService) { 
    if (sessionStorage.getItem('bankbkd') !== null && sessionStorage.getItem('bankbkd') !== 'undefined') {
        this.answers=JSON.parse(sessionStorage.getItem('bankbkd'));
    }
    console.log(sessionStorage);
  }


  insert(id: string, answer: string) {
      console.log(id+ ' ' +answer+' '+this.answers.length);
    this.nextflag=true;
    if(this.next===this.total)
    {
      this.finalbtnflag= true;
    } else{
      this.finalbtnflag=false;
    }
      let flgans=true;
    if (this.answers.length>0)
    {
      console.log("greater");
    for (let i = 0; i < this.answers.length; i++){
      if(this.answers[i].id === id) {
        this.answers[i].ans = answer;
        sessionStorage.setItem('bankbkd', JSON.stringify(this.answers));
        flgans=false;
      }
    }
    if(flgans){
      this.answers.push(new Qa(id, answer));
      sessionStorage.setItem('bankbkd', JSON.stringify(this.answers));
    }
  } else{
      this.answers.push(new Qa(id, answer));
      sessionStorage.setItem('bankbkd', JSON.stringify(this.answers));
  }
    console.log(sessionStorage);
  }

  sesiondatacheck(id: string) {
    for (let i = 0; i < this.answers.length; i++) {
      if (this.answers[i].id === id) {
        return true;
      }
    }
    return false;
  }

  move(direct:string)
  {
    
    
    if(direct==='prev'){
      if(this.previous >-1)
      {
        this.finalbtnflag = false; 
        
        this.service.getJson(''+this.previous).subscribe((res) => {
          this.question = res['result'];
          for (let i = 0; i < this.question.length; i++) {
            for (let j = 0; j < this.answers.length; j++) {
              if (this.answers[j].id === this.question[i].ano) {
                this.question[i].selected = this.answers[j].ans;
                this.nextflag = true;
                break;
              }
            }
          }
          console.log(this.question);
          console.log(this.answers);
        });
        this.previous--;
        this.next--;
      }
      
    } else if(direct==='next'){
      this.nextflag = false;
      this.finalbtnflag = false;
       
          if(this.next <this.total){
            this.service.getJson('' + this.next).subscribe((res) => {
              this.question = res['result'];
              for (let i = 0; i < this.question.length; i++) {
                for (let j = 0; j < this.answers.length; j++) {
                  if (this.answers[j].id === this.question[i].ano) {
                    this.question[i].selected = this.answers[j].ans;
                    this.nextflag = true;
                    if (this.next === this.total) {
                      this.finalbtnflag = true;
                    }
                    break;
                  }
                }
              }
              
              console.log(this.question);
              console.log(this.answers);
            });
            this.previous++;
            this.next++;
          }
    }
  }

  finalizer()
  {
    this.finalcorrect = 0;
    this.finalwrong = 0;
    this.finalclick=true;
    let finalflag=0;
    this.service.getall().subscribe((res) => {
      this.question = res['result'];
      for (let i = 0; i < this.question.length; i++) {
        finalflag = 0;
        for (let j = 0; j < this.answers.length; j++) {
          if (this.answers[j].id === this.question[i].ano ) {

            this.question[i].selected = this.answers[j].ans;
            if (this.question[i].correct === this.answers[j].ans){
            this.question[i].validate = 'correct';
            finalflag = 1;
            break;
            }
          }
          
        }
        if (finalflag === 1) {
          this.finalcorrect++;
        } else{
          this.finalwrong++;
        }
      }
      console.log(this.question);
      console.log(this.answers);
    });
  }

  ngOnInit() {
    this.service.getTotal().subscribe((res) => {
      this.total = res['result'];
    });

    this.service.getJson('0').subscribe((res) => {
      this.question = res['result'];
      for ( let i = 0 ; i < this.question.length; i++){
           for(let j=0;j< this.answers.length; j++){
             if(this.answers[j].id=== this.question[i].ano ){
               this.question[i].selected = this.answers[j].ans;
               this.nextflag=true;
               break;
             }
           }
      }
      console.log(this.question);
      console.log(this.answers);
    });

  }

}
