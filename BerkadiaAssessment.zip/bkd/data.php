<?php
header('Content-Type: application/json');
$con=mysqli_connect("localhost","root","","question");
$result=array();
if(isset($_GET['single'])){
$n=$_GET['single'];
$sql="select * from data limit $n , 1";
$q=mysqli_query($con,$sql);
$arr=array();
while($row=mysqli_fetch_assoc($q))
{
 $row["selected"]="";
 array_push($arr,$row);
}
$result["result"]=$arr;
echo json_encode($result,JSON_PRETTY_PRINT);
}
else if(isset($_GET['total']))
{
$sql="select * from data ";
$q=mysqli_query($con,$sql);
$result["result"]=mysqli_num_rows($q);
echo json_encode($result,JSON_PRETTY_PRINT);
}
else if(isset($_GET['alldata']))
{
$sql="select * from data ";
$q=mysqli_query($con,$sql);
$arr=array();
while($row=mysqli_fetch_assoc($q))
{
 $row["selected"]="";
 $row["validate"]="";
 array_push($arr,$row);
}
$result["result"]=$arr;
echo json_encode($result,JSON_PRETTY_PRINT);
}
?>